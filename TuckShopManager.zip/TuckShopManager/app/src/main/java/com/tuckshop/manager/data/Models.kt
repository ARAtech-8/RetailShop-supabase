package com.tuckshop.manager.data

/** Payment methods stored on a sale. */
object Method {
    const val CASH = "CASH"
    const val MOBILE = "MOBILE"
    const val CREDIT = "CREDIT"

    fun label(m: String): String = when (m) {
        CASH -> "Cash"
        MOBILE -> "Mobile money"
        CREDIT -> "On credit"
        else -> m
    }
}

/** costPrice is 0 for employees: the server never sends it to them. */
data class Product(
    val id: Long = 0,
    val name: String,
    val category: String = "General",
    val unit: String = "each",
    val costPrice: Double = 0.0,
    val sellPrice: Double = 0.0,
    val stockQty: Double = 0.0,
    val reorderLevel: Double = 5.0,
    val active: Boolean = true,
    val createdAt: Long = 0L
)

data class Customer(val id: Long = 0, val name: String, val phone: String = "")

data class Sale(
    val id: Long = 0,
    val time: Long = 0L,
    val total: Double,
    val method: String,
    val customerId: Long? = null,
    val note: String = "",
    val voided: Boolean = false,
    val createdByName: String = "",
    val createdBy: String = ""
)

data class SaleItem(
    val id: Long = 0,
    val saleId: Long,
    val productId: Long,
    val name: String,
    val qty: Double,
    val unitPrice: Double,
    val unitCost: Double = 0.0
)

data class Restock(
    val id: Long = 0,
    val time: Long = 0L,
    val productId: Long,
    val productName: String,
    val qty: Double,
    val unitCost: Double,
    val supplier: String = "",
    val paidNow: Double
)

data class SupplierPayment(val id: Long = 0, val time: Long = 0L, val supplier: String, val amount: Double, val note: String = "")

data class Expense(val id: Long = 0, val time: Long = 0L, val category: String, val amount: Double, val note: String = "")

data class OwnerTxn(val id: Long = 0, val time: Long = 0L, val amount: Double, val note: String = "")

data class CustomerPayment(val id: Long = 0, val customerId: Long, val time: Long = 0L, val amount: Double, val note: String = "")

/** One sold line with its sale's time, payment method and the employee who made the sale. */
data class SaleLine(
    val saleId: Long,
    val productId: Long,
    val name: String,
    val qty: Double,
    val unitPrice: Double,
    val unitCost: Double,
    val saleTime: Long,
    val method: String,
    val staff: String = ""
)

data class NameAmount(val name: String, val amount: Double)

/** One line in the shopping cart on the Sell screen. */
data class CartLine(val product: Product, val qty: Double, val price: Double)

/** One row of a product sheet read from Excel/CSV. Null means "the sheet had no value". */
data class ImportRow(
    val name: String,
    val category: String,
    val unit: String,
    val cost: Double?,
    val sell: Double?,
    val qty: Double?,
    val reorder: Double?
)

data class CustomerBalance(val customer: Customer, val owed: Double)

// ------------------------------------------------------------------------- accounts
enum class Role { OWNER, EMPLOYEE }

data class ShopInfo(
    val id: String,
    val code: String,
    val name: String,
    val symbol: String,
    val openingMoney: Double,
    val licenseKey: String?,
    val allowEmployeeCredit: Boolean,
    val migratedAt: Long?,
    val createdAt: Long
)

data class MemberInfo(
    val userId: String,
    val role: Role,
    val username: String,
    val displayName: String,
    val active: Boolean
)

data class ActivityEntry(val id: Long, val time: Long, val userName: String, val action: String, val detail: String)

sealed class AuthState {
    object Loading : AuthState()
    object SignedOut : AuthState()
    /** Signed in, but not attached to any active shop. */
    data class NoAccess(val isStaffLogin: Boolean) : AuthState()
    data class Failed(val message: String) : AuthState()
    data class In(val member: MemberInfo, val shop: ShopInfo) : AuthState() {
        val isOwner: Boolean get() = member.role == Role.OWNER
    }
}
