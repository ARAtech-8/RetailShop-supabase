package com.tuckshop.manager.domain

import com.tuckshop.manager.data.NameAmount
import com.tuckshop.manager.data.Product
import com.tuckshop.manager.data.SaleLine
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.round

data class ShopSettings(
    val shopName: String = "My Tuck Shop",
    val symbol: String = "$",
    /** Money (cash + mobile money) the shop had on the day the owner started using the app. */
    val openingMoney: Double = 0.0
)

/** Reporting periods the owner can pick. */
enum class Period(val label: String) {
    TODAY("Today"),
    WEEK("This week"),
    MONTH("This month"),
    M3("Last 3 months"),
    M6("Last 6 months"),
    Y1("Last 12 months")
}

/** Half-open time range: start <= t < end (epoch millis). */
data class TimeRange(val start: Long, val end: Long) {
    /** The stretch of time of the same length that came just before this one. */
    fun previous(): TimeRange = TimeRange(start - (end - start), start)
}

fun Period.range(now: Long = System.currentTimeMillis()): TimeRange {
    val c = Calendar.getInstance()
    c.timeInMillis = now
    c.set(Calendar.HOUR_OF_DAY, 0)
    c.set(Calendar.MINUTE, 0)
    c.set(Calendar.SECOND, 0)
    c.set(Calendar.MILLISECOND, 0)
    when (this) {
        Period.TODAY -> {}
        Period.WEEK -> {
            // Weeks run Monday to Sunday. Calendar: Sunday = 1 ... Saturday = 7.
            val back = (c.get(Calendar.DAY_OF_WEEK) + 5) % 7
            c.add(Calendar.DAY_OF_YEAR, -back)
        }
        Period.MONTH -> c.set(Calendar.DAY_OF_MONTH, 1)
        Period.M3 -> c.add(Calendar.MONTH, -3)
        Period.M6 -> c.add(Calendar.MONTH, -6)
        Period.Y1 -> c.add(Calendar.YEAR, -1)
    }
    return TimeRange(c.timeInMillis, now + 1)
}

/** The stretch of time just before this period, shifted back by one "unit" of the period. */
fun Period.previousRange(now: Long = System.currentTimeMillis()): TimeRange {
    val r = range(now)
    fun shift(t: Long): Long {
        val c = Calendar.getInstance()
        c.timeInMillis = t
        when (this) {
            Period.TODAY -> c.add(Calendar.DAY_OF_YEAR, -1)
            Period.WEEK -> c.add(Calendar.DAY_OF_YEAR, -7)
            Period.MONTH -> c.add(Calendar.MONTH, -1)
            Period.M3 -> c.add(Calendar.MONTH, -3)
            Period.M6 -> c.add(Calendar.MONTH, -6)
            Period.Y1 -> c.add(Calendar.YEAR, -1)
        }
        return c.timeInMillis
    }
    return TimeRange(shift(r.start), shift(r.end))
}

/** Plain-words label for comparing with the previous stretch of time. */
val Period.compareLabel: String
    get() = when (this) {
        Period.TODAY -> "than yesterday"
        Period.WEEK -> "than last week"
        Period.MONTH -> "than last month"
        Period.M3 -> "than the 3 months before"
        Period.M6 -> "than the 6 months before"
        Period.Y1 -> "than the year before"
    }

object Fmt {
    fun money(v: Double): String {
        val r = if (abs(v) < 0.005) 0.0 else v
        return String.format(Locale.US, "%,.2f", r)
    }

    fun qty(q: Double): String =
        if (abs(q - round(q)) < 0.0001) String.format(Locale.US, "%d", round(q).toLong())
        else String.format(Locale.US, "%.2f", q).trimEnd('0').trimEnd('.')

    fun pct(v: Double): String = String.format(Locale.US, "%.1f%%", v)

    fun date(t: Long): String = SimpleDateFormat("d MMM yyyy", Locale.US).format(Date(t))
    fun dateTime(t: Long): String = SimpleDateFormat("d MMM, HH:mm", Locale.US).format(Date(t))
    fun fileStamp(t: Long): String = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date(t))
}

data class Summary(
    val sales: Double,
    val cost: Double,
    val units: Double,
    val count: Int
) {
    val profit: Double get() = sales - cost
    val margin: Double get() = if (sales > 0.0) profit / sales * 100.0 else 0.0
    val avgSale: Double get() = if (count > 0) sales / count else 0.0
}

data class ProductStat(
    val productId: Long,
    val name: String,
    val qty: Double,
    val revenue: Double,
    val cost: Double
) {
    val profit: Double get() = revenue - cost
    val margin: Double get() = if (revenue > 0.0) profit / revenue * 100.0 else 0.0
}

enum class BucketKind { HOUR, DAY, WEEK, MONTH }

data class Bucket(val label: String, val sales: Double, val profit: Double)

data class ReorderItem(
    val product: Product,
    val daysLeft: Double?,
    val suggested: Double
)

/** Everything the statements need for one period, loaded from the database. */
data class RawData(
    val range: TimeRange,
    val lines: List<SaleLine>,
    val salesByMethod: List<NameAmount>,
    val expenses: List<NameAmount>,
    val losses: List<NameAmount>,
    val restockPaid: Double,
    val restockTotal: Double,
    val supplierPaid: Double,
    val customerPaid: Double,
    val ownerIn: Double,
    val ownerOut: Double,
    val openingMoney: Double
) {
    fun method(m: String): Double = salesByMethod.firstOrNull { it.name == m }?.amount ?: 0.0

    /** Money actually received from sales in the period (cash + mobile money). */
    val salesReceived: Double get() = salesByMethod.filter { it.name != "CREDIT" }.sumOf { it.amount }
    val soldOnCredit: Double get() = method("CREDIT")
    val expenseTotal: Double get() = expenses.sumOf { it.amount }
    val lossTotal: Double get() = losses.sumOf { it.amount }

    val moneyIn: Double get() = salesReceived + customerPaid
    val moneyOut: Double get() = restockPaid + supplierPaid + expenseTotal
    val fromRunning: Double get() = moneyIn - moneyOut
    val fromOwner: Double get() = ownerIn - ownerOut
    val closingMoney: Double get() = openingMoney + fromRunning + fromOwner
}

/** A snapshot of what the shop has and owes right now. */
data class Position(
    val money: Double,
    val stockValue: Double,
    val debtors: List<NameAmount>,
    val creditors: List<NameAmount>
) {
    val owedToShop: Double get() = debtors.sumOf { it.amount }
    val owedByShop: Double get() = creditors.sumOf { it.amount }
    val totalHas: Double get() = money + stockValue + owedToShop
    val netWorth: Double get() = totalHas - owedByShop
}

data class ReportBundle(
    val period: Period,
    val range: TimeRange,
    val raw: RawData,
    val summary: Summary,
    val prev: Summary,
    val stats: List<ProductStat>,
    val trend: List<Bucket>,
    val trendKind: BucketKind,
    val products: List<Product>,
    val notSelling: List<Product>,
    val reorder: List<ReorderItem>,
    val position: Position,
    val busiestHour: Pair<Int, Double>?,
    val bestWeekday: Pair<String, Double>?
) {
    val rangeText: String
        get() = if (period == Period.TODAY) Fmt.date(range.start)
        else Fmt.date(range.start) + " to " + Fmt.date(range.end - 1)
}
