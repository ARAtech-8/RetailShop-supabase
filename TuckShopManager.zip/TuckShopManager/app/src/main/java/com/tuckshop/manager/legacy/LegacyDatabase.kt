package com.tuckshop.manager.legacy

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

/**
 * The old on-phone database. The table layout is identical to version 1 of the app, so existing
 * installs open it without any migration. It is only ever read.
 */
@Database(
    entities = [
        LegacyProduct::class, LegacyCustomer::class, LegacySale::class, LegacySaleItem::class, LegacyRestock::class,
        LegacySupplierPayment::class, LegacyAdjustment::class, LegacyExpense::class, LegacyOwnerTxn::class,
        LegacyCustomerPayment::class
    ],
    version = 1,
    exportSchema = false
)
abstract class LegacyDatabase : RoomDatabase() {
    abstract fun dao(): LegacyDao

    companion object {
        const val NAME = "tuckshop.db"

        fun exists(context: Context): Boolean = context.getDatabasePath(NAME).exists()

        fun build(context: Context): LegacyDatabase =
            Room.databaseBuilder(context.applicationContext, LegacyDatabase::class.java, NAME)
                .setJournalMode(JournalMode.TRUNCATE)
                .build()
    }
}
