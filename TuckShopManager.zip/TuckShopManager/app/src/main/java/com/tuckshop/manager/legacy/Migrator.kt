package com.tuckshop.manager.legacy

import android.content.Context
import com.tuckshop.manager.data.SettingsStore
import com.tuckshop.manager.net.Api
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

/**
 * One-time move of the records that the old phone-only version kept, into the owner's cloud shop.
 * Runs in steps; if it stops half way (e.g. no internet) nothing is marked as finished, but the owner should
 * check the Stock and Sales lists before trying again, because the earlier steps may already have been saved.
 */
object Migrator {

    fun hasOldRecords(context: Context): Boolean = LegacyDatabase.exists(context)

    class Counts(val products: Int, val customers: Int, val sales: Int, val other: Int)

    suspend fun count(context: Context): Counts = withContext(Dispatchers.IO) {
        val db = LegacyDatabase.build(context)
        try {
            val d = db.dao()
            Counts(
                d.products().size, d.customers().size, d.sales().size,
                d.restocks().size + d.supplierPayments().size + d.adjustments().size + d.expenses().size +
                    d.ownerTxns().size + d.customerPayments().size
            )
        } finally {
            db.close()
        }
    }

    suspend fun run(context: Context, api: Api, progress: (String) -> Unit) = withContext(Dispatchers.IO) {
        val db = LegacyDatabase.build(context)
        try {
            val d = db.dao()
            val settings = SettingsStore(context).state.value

            progress("Moving products...")
            val pMap = HashMap<Long, Long>()
            for (chunk in d.products().chunked(200)) {
                val arr = JSONArray()
                for (p in chunk) {
                    arr.put(
                        JSONObject().put("id", p.id).put("name", p.name).put("category", p.category).put("unit", p.unit)
                            .put("cost", p.costPrice).put("sell", p.sellPrice).put("qty", p.stockQty)
                            .put("reorder", p.reorderLevel).put("active", p.active).put("created", p.createdAt)
                    )
                }
                val res = api.rpcArray("migrate_products", JSONObject().put("p_rows", arr))
                for (i in 0 until res.length()) pMap[res.getJSONObject(i).getLong("old")] = res.getJSONObject(i).getLong("new")
            }

            progress("Moving customers...")
            val cMap = HashMap<Long, Long>()
            for (chunk in d.customers().chunked(200)) {
                val arr = JSONArray()
                for (c in chunk) arr.put(JSONObject().put("id", c.id).put("name", c.name).put("phone", c.phone))
                val res = api.rpcArray("migrate_customers", JSONObject().put("p_rows", arr))
                for (i in 0 until res.length()) cMap[res.getJSONObject(i).getLong("old")] = res.getJSONObject(i).getLong("new")
            }

            progress("Moving sales...")
            val items = d.saleItems().groupBy { it.saleId }
            val sales = d.sales()
            var done = 0
            for (chunk in sales.chunked(100)) {
                val arr = JSONArray()
                for (s in chunk) {
                    val its = JSONArray()
                    for (it in items[s.id].orEmpty()) {
                        val np = pMap[it.productId] ?: continue
                        its.put(
                            JSONObject().put("product_id", np).put("name", it.name).put("qty", it.qty)
                                .put("unit_price", it.unitPrice).put("unit_cost", it.unitCost)
                        )
                    }
                    arr.put(
                        JSONObject().put("time", s.time).put("total", s.total).put("method", s.method)
                            .put("customer_id", s.customerId?.let { cMap[it] } ?: JSONObject.NULL)
                            .put("note", s.note).put("voided", s.voided).put("items", its)
                    )
                }
                api.rpc("migrate_sales", JSONObject().put("p_rows", arr))
                done += chunk.size
                progress("Moving sales... $done of ${sales.size}")
            }

            progress("Moving stock purchases, expenses and payments...")
            val data = JSONObject()
            data.put("restocks", JSONArray().also { a ->
                for (r in d.restocks()) a.put(
                    JSONObject().put("time", r.time).put("product_id", pMap[r.productId] ?: continue).put("product_name", r.productName)
                        .put("qty", r.qty).put("unit_cost", r.unitCost).put("supplier", r.supplier).put("paid_now", r.paidNow)
                )
            })
            data.put("supplier_payments", JSONArray().also { a ->
                for (r in d.supplierPayments()) a.put(
                    JSONObject().put("time", r.time).put("supplier", r.supplier).put("amount", r.amount).put("note", r.note)
                )
            })
            data.put("adjustments", JSONArray().also { a ->
                for (r in d.adjustments()) a.put(
                    JSONObject().put("time", r.time).put("product_id", pMap[r.productId] ?: continue).put("product_name", r.productName)
                        .put("qty_change", r.qtyChange).put("unit_cost", r.unitCost).put("reason", r.reason)
                )
            })
            data.put("expenses", JSONArray().also { a ->
                for (r in d.expenses()) a.put(
                    JSONObject().put("time", r.time).put("category", r.category).put("amount", r.amount).put("note", r.note)
                )
            })
            data.put("owner_txns", JSONArray().also { a ->
                for (r in d.ownerTxns()) a.put(JSONObject().put("time", r.time).put("amount", r.amount).put("note", r.note))
            })
            data.put("customer_payments", JSONArray().also { a ->
                for (r in d.customerPayments()) a.put(
                    JSONObject().put("customer_id", cMap[r.customerId] ?: continue).put("time", r.time)
                        .put("amount", r.amount).put("note", r.note)
                )
            })
            api.rpc("migrate_other", JSONObject().put("p_data", data))

            progress("Finishing...")
            api.rpc(
                "migrate_finish",
                JSONObject().put("p_name", settings.shopName).put("p_symbol", settings.symbol).put("p_opening", settings.openingMoney)
            )
        } finally {
            db.close()
        }
    }
}
