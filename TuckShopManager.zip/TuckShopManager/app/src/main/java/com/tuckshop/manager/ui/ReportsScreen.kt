@file:OptIn(ExperimentalMaterial3Api::class)

package com.tuckshop.manager.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.tuckshop.manager.ShopViewModel
import com.tuckshop.manager.data.Method
import com.tuckshop.manager.domain.Doc
import com.tuckshop.manager.domain.DocBuilder
import com.tuckshop.manager.domain.Fmt
import com.tuckshop.manager.domain.Period
import com.tuckshop.manager.domain.ReportBundle
import com.tuckshop.manager.domain.ShopSettings
import com.tuckshop.manager.domain.compareLabel
import com.tuckshop.manager.io.CsvExporter
import com.tuckshop.manager.io.PdfExporter
import com.tuckshop.manager.io.Share

// ============================================================================ exports
class ExportActions(
    val sharePdf: (List<Doc>, ReportBundle, String) -> Unit,
    val savePdf: (List<Doc>, ReportBundle, String) -> Unit,
    val saveCsv: (List<Doc>, ReportBundle, String) -> Unit
)

@Composable
fun rememberExportActions(vm: ShopViewModel): ExportActions {
    val ctx = LocalContext.current
    val settings by vm.settings.collectAsState()
    var pending by remember { mutableStateOf<ByteArray?>(null) }

    fun write(uri: Uri?) {
        val bytes = pending
        if (uri == null || bytes == null) return
        try {
            ctx.contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
            vm.say("Saved. Look for it in the folder you chose.")
        } catch (e: Exception) {
            vm.say("Could not save the file.")
        }
        pending = null
    }

    val pdfSaver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { write(it) }
    val csvSaver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { write(it) }

    fun name(s: ShopSettings, base: String, ext: String): String =
        s.shopName.replace(Regex("[^A-Za-z0-9]+"), "_").trim('_') + "_" + base + "_" + Fmt.fileStamp(System.currentTimeMillis()) + "." + ext

    return remember(settings) {
        ExportActions(
            sharePdf = { docs, b, base ->
                val bytes = PdfExporter.build(settings, b.period.label, b.rangeText, docs)
                Share.shareFile(ctx, bytes, name(settings, base, "pdf"), "application/pdf")
            },
            savePdf = { docs, b, base ->
                pending = PdfExporter.build(settings, b.period.label, b.rangeText, docs)
                pdfSaver.launch(name(settings, base, "pdf"))
            },
            saveCsv = { docs, b, base ->
                pending = CsvExporter.build(settings, b.period.label, b.rangeText, docs)
                csvSaver.launch(name(settings, base, "csv"))
            }
        )
    }
}

// ============================================================================ reports tab
@Composable
fun ReportsScreen(vm: ShopViewModel, nav: NavHostController) {
    var period by rememberSaveable { mutableStateOf(Period.MONTH) }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val version by vm.repo.version.collectAsState()
    val bundle by produceState<ReportBundle?>(null, period, version) { value = try { vm.repo.bundle(period) } catch (e: Exception) { value } }
    val settings by vm.settings.collectAsState()
    val export = rememberExportActions(vm)

    ScreenFrame("Reports", actions = { RefreshAction(vm) }) {
        TabRow(selectedTabIndex = tab) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Insights") })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Statements") })
        }
        PeriodChips(period) { period = it }
        val b = bundle
        if (b == null || b.period != period) {
            EmptyHint("Working it out...")
        } else if (tab == 0) {
            InsightsTab(vm, b)
        } else {
            val docs = DocBuilder(settings, b).all()
            Column(
                Modifier.verticalScroll(rememberScrollState()).padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    b.period.label + ":  " + b.rangeText,
                    color = Ui.Muted, fontSize = 13.sp
                )
                WhiteCard {
                    Text("Everything in one file", fontWeight = FontWeight.Bold)
                    Text(
                        "All statements below for this period, ready to send to the bank, a partner or your accountant.",
                        fontSize = 12.sp, color = Ui.Muted, modifier = Modifier.padding(vertical = 6.dp)
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { export.sharePdf(docs, b, "all_reports") }) { Text("Share PDF") }
                        FilledTonalButton(onClick = { export.savePdf(docs, b, "all_reports") }) { Text("Save PDF") }
                        OutlinedButton(onClick = { export.saveCsv(docs, b, "all_reports") }) { Text("Excel") }
                    }
                }
                docs.forEach { d ->
                    Card(
                        Modifier.fillMaxWidth().clickable { nav.navigate("doc/" + d.key + "/" + b.period.name) },
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Column(Modifier.padding(14.dp)) {
                            Text(d.title, fontWeight = FontWeight.Bold)
                            Text(d.blurb, fontSize = 12.sp, color = Ui.Muted)
                        }
                    }
                }
            }
        }
    }
}

// ============================================================================ one statement
@Composable
fun DocScreen(vm: ShopViewModel, key: String, periodName: String, onBack: () -> Unit) {
    val period = try { Period.valueOf(periodName) } catch (e: Exception) { Period.MONTH }
    val version by vm.repo.version.collectAsState()
    val settings by vm.settings.collectAsState()
    val bundle by produceState<ReportBundle?>(null, period, version) { value = try { vm.repo.bundle(period) } catch (e: Exception) { value } }
    val export = rememberExportActions(vm)
    val b = bundle

    ScreenFrame("Statement", onBack = onBack) {
        if (b == null) {
            EmptyHint("Working it out...")
        } else {
            val doc = DocBuilder(settings, b).all().firstOrNull { it.key == key }
            if (doc == null) {
                EmptyHint("Statement not found.")
            } else {
                Column(
                    Modifier.verticalScroll(rememberScrollState()).padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(doc.title, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text(b.period.label + ":  " + b.rangeText, color = Ui.Muted, fontSize = 13.sp)
                    Text(doc.blurb, fontSize = 13.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { export.sharePdf(listOf(doc), b, doc.key) }) { Text("Share PDF") }
                        FilledTonalButton(onClick = { export.savePdf(listOf(doc), b, doc.key) }) { Text("Save PDF") }
                        OutlinedButton(onClick = { export.saveCsv(listOf(doc), b, doc.key) }) { Text("Excel") }
                    }
                    DocView(doc, settings.symbol)
                }
            }
        }
    }
}

// ============================================================================ insights
@Composable
private fun InsightsTab(vm: ShopViewModel, b: ReportBundle) {
    val s = b.summary
    val ctx = LocalContext.current
    Column(
        Modifier.verticalScroll(rememberScrollState()).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (s.count == 0) {
            WhiteCard {
                Text("No sales in this period yet.", fontWeight = FontWeight.Bold)
                Text("Record sales on the Sell tab and your insights will appear here.", color = Ui.Muted)
            }
        } else {
            WhiteCard {
                Text(
                    "You sold " + money(s.sales) + " and " +
                        (if (s.profit >= 0) "made a profit of " else "lost ") + money(kotlin.math.abs(s.profit)) +
                        " on the goods, before running costs.",
                    fontSize = 16.sp
                )
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                val chS = changeText(s.sales, b.prev.sales, b.period.compareLabel)
                StatCard("Turnover (total sales)", money(s.sales), Modifier.weight(1f), sub = chS?.first, subColor = chS?.second ?: Ui.Muted)
                val chP = changeText(s.profit, b.prev.profit, b.period.compareLabel)
                StatCard("Profit on goods", money(s.profit), Modifier.weight(1f), profitColor(s.profit), chP?.first, chP?.second ?: Ui.Muted)
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatCard("Profit margin", Fmt.pct(s.margin), Modifier.weight(1f), sub = "kept from each 100 sold")
                StatCard("Items sold", Fmt.qty(s.units), Modifier.weight(1f), sub = s.count.toString() + " sales, avg " + money(s.avgSale))
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                val net = s.profit - b.raw.lossTotal - b.raw.expenseTotal
                StatCard("Profit after all costs", money(net), Modifier.weight(1f), profitColor(net), "after expenses and stock losses")
                StatCard("Money in the shop now", money(b.position.money), Modifier.weight(1f), sub = "cash + mobile money")
            }

            WhiteCard {
                SectionTitle("Sales over time", "Each bar is one " + when (b.trendKind) {
                    com.tuckshop.manager.domain.BucketKind.HOUR -> "hour"
                    com.tuckshop.manager.domain.BucketKind.DAY -> "day"
                    com.tuckshop.manager.domain.BucketKind.WEEK -> "week"
                    com.tuckshop.manager.domain.BucketKind.MONTH -> "month"
                })
                SalesChart(b.trend)
                val parts = ArrayList<String>()
                b.bestWeekday?.let { parts.add("Best day: " + it.first) }
                b.busiestHour?.let {
                    val h = it.first
                    parts.add("Busiest hour: " + (if (h % 12 == 0) 12 else h % 12) + (if (h < 12) "am" else "pm"))
                }
                if (parts.isNotEmpty()) Text(parts.joinToString("   |   "), fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
            }

            val byRev = b.stats.sortedByDescending { it.revenue }
            WhiteCard {
                SectionTitle("Best sellers by turnover", "Items that brought in the most money")
                RankBars(byRev.take(5).map { RankItem(it.name, it.revenue, money(it.revenue)) }, Ui.Good)
            }
            if (byRev.size > 5) {
                WhiteCard {
                    SectionTitle("Slowest sellers", "Items that sold, but brought in the least")
                    RankBars(byRev.takeLast(5).reversed().map { RankItem(it.name, it.revenue, money(it.revenue)) }, Ui.Warn)
                }
            }
            val byProfit = b.stats.sortedByDescending { it.profit }
            WhiteCard {
                SectionTitle("Most profitable items", "Where your profit really comes from")
                RankBars(byProfit.filter { it.profit > 0 }.take(5).map { RankItem(it.name, it.profit, money(it.profit)) }, Ui.Good)
            }
            val losers = b.stats.filter { it.profit < -0.004 }.sortedBy { it.profit }
            WhiteCard {
                SectionTitle("Items losing you money", "You sold these for less than they cost")
                if (losers.isEmpty()) Text("None. Every item you sold made a profit.", color = Ui.Good)
                else {
                    RankBars(losers.take(8).map { RankItem(it.name, it.profit, money(it.profit)) }, Ui.Bad)
                    Text("Check the selling price of these items, or ask your supplier for a better price.", fontSize = 12.sp, color = Ui.Muted, modifier = Modifier.padding(top = 6.dp))
                }
            }
            val thin = b.stats.filter { it.profit >= 0 && it.revenue > 0 && it.margin < 10.0 }.sortedBy { it.margin }
            if (thin.isNotEmpty()) {
                WhiteCard {
                    SectionTitle("Very small profit", "You keep less than 10 out of every 100 on these")
                    RankBars(thin.take(5).map { RankItem(it.name, it.margin, Fmt.pct(it.margin)) }, Ui.Warn)
                }
            }

            WhiteCard {
                SectionTitle("How customers paid")
                val pay = b.raw.salesByMethod.filter { it.amount > 0 }.sortedByDescending { it.amount }
                RankBars(pay.map { RankItem(Method.label(it.name), it.amount, money(it.amount)) }, Ui.Good)
            }
        }

        if (b.notSelling.isNotEmpty()) {
            val tied = b.notSelling.sumOf { it.stockQty * it.costPrice }
            WhiteCard {
                SectionTitle("Not selling at all", "Sitting on the shelf, no sales in this period")
                Text(money(tied) + " of your money is tied up in these.", color = Ui.Warn, fontWeight = FontWeight.Bold)
                Text(
                    b.notSelling.take(10).joinToString(", ") { it.name } + (if (b.notSelling.size > 10) " and more..." else ""),
                    modifier = Modifier.padding(top = 4.dp), fontSize = 13.sp
                )
                Text("Think about a special price, or stop buying these.", fontSize = 12.sp, color = Ui.Muted, modifier = Modifier.padding(top = 4.dp))
            }
        }

        if (b.reorder.isNotEmpty()) {
            WhiteCard {
                SectionTitle("Time to buy more", "Running low or about to run out")
                b.reorder.take(8).forEach {
                    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(it.product.name, Modifier.weight(1f))
                        Text(
                            "have " + Fmt.qty(maxOf(0.0, it.product.stockQty)) + ", buy about " + Fmt.qty(it.suggested),
                            fontSize = 12.sp, color = Ui.Muted
                        )
                    }
                }
                OutlinedButton(
                    onClick = {
                        Share.shareText(
                            ctx,
                            "Shopping list - " + vm.settings.value.shopName + "\n" +
                                b.reorder.joinToString("\n") { "- " + it.product.name + ": about " + Fmt.qty(it.suggested) }
                        )
                    },
                    modifier = Modifier.padding(top = 8.dp)
                ) { Text("Send shopping list (WhatsApp...)") }
            }
        }
    }
}
