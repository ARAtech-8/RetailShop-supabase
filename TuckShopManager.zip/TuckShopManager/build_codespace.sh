#!/usr/bin/env bash
# Builds the Tuck Shop Manager APK inside a GitHub Codespace (or any Linux terminal).
# Usage:  bash build_codespace.sh
set -e
cd "$(dirname "$0")"

export ANDROID_HOME="$HOME/android-sdk"
export ANDROID_SDK_ROOT="$ANDROID_HOME"
GRADLE_VERSION=8.10.2

echo "== Java (needs 17)"
if ! java -version 2>&1 | grep -q '"17\.'; then
  sudo apt-get update -qq && sudo apt-get install -y -qq openjdk-17-jdk-headless
fi
if [ -d /usr/lib/jvm/java-17-openjdk-amd64 ]; then export JAVA_HOME=/usr/lib/jvm/java-17-openjdk-amd64; fi
if [ -d /usr/lib/jvm/java-17-openjdk-arm64 ]; then export JAVA_HOME=/usr/lib/jvm/java-17-openjdk-arm64; fi
[ -n "$JAVA_HOME" ] && export PATH="$JAVA_HOME/bin:$PATH"
java -version 2>&1 | head -1

echo "== Android SDK"
if [ ! -x "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" ]; then
  mkdir -p "$ANDROID_HOME/cmdline-tools"
  curl -fsSL -o /tmp/cmdtools.zip https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip
  unzip -q -o /tmp/cmdtools.zip -d "$ANDROID_HOME/cmdline-tools"
  rm -rf "$ANDROID_HOME/cmdline-tools/latest"
  mv "$ANDROID_HOME/cmdline-tools/cmdline-tools" "$ANDROID_HOME/cmdline-tools/latest"
fi
export PATH="$ANDROID_HOME/cmdline-tools/latest/bin:$PATH"
yes | sdkmanager --licenses > /dev/null || true
sdkmanager "platform-tools" "platforms;android-35" "build-tools;35.0.0"

echo "== Gradle $GRADLE_VERSION"
if [ ! -x "$HOME/gradle-$GRADLE_VERSION/bin/gradle" ]; then
  curl -fsSL -o /tmp/gradle.zip "https://services.gradle.org/distributions/gradle-$GRADLE_VERSION-bin.zip"
  unzip -q -o /tmp/gradle.zip -d "$HOME"
fi
export PATH="$HOME/gradle-$GRADLE_VERSION/bin:$PATH"

echo "sdk.dir=$ANDROID_HOME" > local.properties

echo "== Building"
gradle :app:assembleDebug --no-daemon --stacktrace

APK=app/build/outputs/apk/debug/app-debug.apk
echo
echo "DONE. APK is here: $PWD/$APK"
ls -la "$APK"
